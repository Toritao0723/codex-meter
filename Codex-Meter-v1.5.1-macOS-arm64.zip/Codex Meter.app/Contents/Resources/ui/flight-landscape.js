// Layered mountain artwork, converted through Tori Patterns' photo-style sampler.
// The grayscale source is baked once per size/theme; only the layers drift.
(() => {
  const cache = new WeakMap();
  const fract = x => x-Math.floor(x);
  const hash = n => fract(Math.sin(n*127.1+31.7)*43758.5453);
  const triangle = x => 1-Math.abs(2*fract(x)-1);
  function source(width,height,near) {
    const c=document.createElement('canvas'); c.width=width; c.height=height;
    const g=c.getContext('2d'); g.fillStyle='#000'; g.fillRect(0,0,width,height);
    const ridge = u => height*(near
      ? 1.05-.40*triangle(u*4+.1)-.06*triangle(u*9)
      : .8-.43*triangle(u*3+.2)-.13*triangle(u*7+.4));
    const vertices=[];
    for(let x=0;x<=width;x+=2) vertices.push([x,ridge(x/width)]);
    const mountain = g.createLinearGradient(0,height*.25,0,height);
    mountain.addColorStop(0,near?'#b0b0b0':'#929292');
    mountain.addColorStop(1,near?'#303030':'#242424');
    g.fillStyle=mountain;g.beginPath();g.moveTo(0,height);
    for(const [x,y] of vertices) g.lineTo(x,y);
    g.lineTo(width,height);g.closePath();g.fill();
    // Faceted rock: light and shadow follow the slope beneath each summit.
    g.save();g.clip();
    for(let i=0;i<16;i++) {
      const x=i*width/16, top=ridge(x/width);
      g.fillStyle=i%2?'rgba(230,230,230,.23)':'rgba(0,0,0,.5)';
      g.beginPath();g.moveTo(x,top);g.lineTo(x+width*.07,height);g.lineTo(x-width*.035,height);g.closePath();g.fill();
    }
    // Thin snow bands and broken contour lines preserve crisp mountain edges.
    g.strokeStyle=near?'#b7b7b7':'#d7d7d7';g.lineWidth=near?1.5:2.5;
    g.beginPath();for(const [i,[x,y]] of vertices.entries()) i?g.lineTo(x,y+2):g.moveTo(x,y+2);g.stroke();
    g.strokeStyle='rgba(220,220,220,.25)';g.lineWidth=.7;
    for(let line=0;line<5;line++) {
      g.beginPath();for(const [i,[x,y]] of vertices.entries()) {
        const yy=y+7+line*height*.073+Math.sin(x*.09+line)*3;
        i?g.lineTo(x,yy):g.moveTo(x,yy);
      }g.stroke();
    }
    g.restore();
    if(near) {
      // Uneven tree heights, alternating branch tiers, and a visible central trunk.
      for(let i=0;i<13;i++) {
        const x=(i+.3)*width/13, bottom=height*(.98+.07*hash(i));
        const treeH=height*(.14+.2*hash(i+14)), treeW=treeH*.43;
        g.strokeStyle='#aaa';g.lineWidth=1;g.beginPath();g.moveTo(x,bottom-treeH);g.lineTo(x,bottom);g.stroke();
        for(let j=0;j<5;j++) {
          const y=bottom-treeH+j*treeH*.16, w=treeW*(.26+j*.19);
          g.fillStyle=j%2?'#696969':'#c6c6c6';
          g.beginPath();g.moveTo(x,y);g.lineTo(x+w*.5,y+treeH*.28);g.lineTo(x-w*.5,y+treeH*.28);g.closePath();g.fill();
        }
      }
    }
    return c;
  }
  function bake(width,height,dpr,light,near) {
    const layer=document.createElement('canvas');layer.width=Math.round(width*dpr);layer.height=Math.round(height*dpr);
    const ctx=layer.getContext('2d');ctx.scale(dpr,dpr);
    const artwork=source(Math.round(width*3),Math.round(height*3),near);
    const grid=window.PatternField.imageToGrid(artwork,Math.ceil(width/(width<180?2.4:3)));
    window.PatternField.draw(ctx,width,height,grid,{
      ink:light?'#485158':'#d6d4c9', opacity:near?.62:.40, edge:near?.38:.25,
      style:near?'characters':'diagonal',
    });
    return layer;
  }
  function draw(ctx,canvas,{width,height,dpr,theme,time,reduced}) {
    const light=theme==='light', key=`${width}:${height}:${dpr}:${light}`;
    let data=cache.get(canvas);
    if(!data || data.key!==key) {
      data={key,far:bake(width,height,dpr,light,false),near:bake(width,height,dpr,light,true)};
      cache.set(canvas,data);
    }
    const seconds=reduced?0:time/1000;
    ctx.save();
    // A darker valley lets pale characters read while the surrounding panel stays glass.
    ctx.fillStyle=light?'rgba(235,230,215,.16)':'rgba(10,18,24,.27)';ctx.fillRect(0,0,width,height);
    for(const [layer,speed] of [[data.far,1.1],[data.near,2.5]]) {
      const offset=Math.round((seconds*speed%width)*dpr)/dpr;
      ctx.drawImage(layer,-offset,0,width,height);
      ctx.drawImage(layer,width-offset,0,width,height);
    }
    const rgb=light?'65,82,95':'220,220,205';
    // Thin cloud / wind marks cross the open sky, with small, slow star glints.
    ctx.font=`${width<180?4.5:5.5}px Menlo, monospace`;ctx.textAlign='left';
    for(let i=0;i<5;i++) {
      const x=(width*(.13+i*.23)-seconds*.7%width+width)%width;
      const y=height*(.10+.065*(i%3));
      ctx.fillStyle=`rgba(${rgb},.30)`;ctx.fillText(i%2?'_ . _':'- -',x,y);
    }
    for(let i=0;i<10;i++) {
      const x=width*(.05+.9*hash(i+60)), y=height*(.08+.33*hash(i+80));
      const glow=reduced?.35:.22+.22*(.5+.5*Math.sin(seconds*.9+i*2.3));
      ctx.fillStyle=`rgba(${rgb},${glow})`;ctx.fillRect(Math.round(x),Math.round(y),1,1);
      if(i%4===0) { ctx.globalAlpha=.6;ctx.fillRect(Math.round(x)-1,Math.round(y),3,1);ctx.fillRect(Math.round(x),Math.round(y)-1,1,3);ctx.globalAlpha=1; }
    }
    ctx.restore();
  }
  window.FlightLandscape={draw};
})();
