# 当前桌面版本备份

版本：1.3.0（build 6），2026-10-07，macOS Apple Silicon。

`Codex-Meter-v1.3.0-macOS-arm64.zip` 是这次备份时已安装的应用包，含程序与界面，不含账户登录信息、使用量缓存、Codex 任务记录或用户偏好。SHA-256 校验值见 `v1.3.0-manifest.json`。

恢复时先退出正在运行的 Codex Meter，解压并将 `Codex Meter.app` 放回 `~/Applications/`。如果系统因本地临时签名而阻止启动，可从此仓库按主 README 重新构建。源码构建方式：在仓库根目录运行 `./build.sh`，构建结果位于 `/private/tmp/codex-meter-build/Codex Meter.app`。

原作 Claude-Meter 与像素角色 © 2026 Bon Yeung；保留上游署名与 `UPSTREAM.md`。这是个人 Codex 适配版的私有备份。
